import { Link, useLocation } from 'react-router-dom';
import { motion } from 'motion/react';
import ENBLeaf from '@/components/ENBLeaf';
import { AlertTriangle, Home, PlusCircle, Wallet, Store, Trophy, ArrowRightLeft, Settings, ShieldCheck, Shield, Users, CheckSquare, Megaphone, ClipboardList, BarChart2, Globe } from 'lucide-react';
import { useUserStore } from '@/store/user';
import AccountSwitcher from '@/components/AccountSwitcher';
import LanguageToggle from '@/components/LanguageToggle';

export default function DesktopSidebar() {
  const location = useLocation();
  const { user, logout } = useUserStore();

  if (!user) return null;

  const memberNav = [
    { path: '/', icon: Home, label: 'Dashboard' },
    { path: '/submit', icon: PlusCircle, label: 'Submit Action' },
    { path: '/wallet', icon: Wallet, label: 'Wallet' },
    { path: '/directory', icon: Store, label: 'Business Directory' },
    { path: '/leaderboard', icon: Trophy, label: 'Leaderboard' },
    { path: '/bridge', icon: ArrowRightLeft, label: 'Bridge' },
    { path: '/settings', icon: Settings, label: 'Settings' },
  ];

  // Volunteer option — shown to all except onboarding_team and admin (they already have it)
  const volunteerNav = !['onboarding_team', 'admin', 'moderator', 'founder'].includes(user?.role || '') ? [
    { path: '/volunteer-apply', icon: Users, label: 'Join Onboarding Team' },
  ] : [];

  const ALLOWED_LOG_ROLES = ['founder', 'moderator', 'admin', 'organiser'];
  const modNav = ['moderator', 'admin'].includes(user?.role || '') ? [
    { path: '/mod-queue', icon: Shield, label: 'Mod Queue' },
  ] : [];
  const roleBasedNav = ALLOWED_LOG_ROLES.includes(user?.role || '') ? [
    { path: '/my-log', icon: ClipboardList, label: 'Daily Log' },
    { path: '/impact', icon: Globe, label: 'Community Impact' },
    { path: '/governance', icon: BarChart2, label: 'Governance' },
  ] : [];

  const onboardingNav = user?.role === 'onboarding_team' ? [
    { path: '/onboarding-queue', icon: Store, label: 'Client Onboarding' },
  ] : [];

  const adminNav = [
    { path: '/admin', icon: Home, label: 'Overview' },
    { path: '/admin/users', icon: Users, label: 'Members' },
    { path: '/admin/campaigns', icon: Megaphone, label: 'Campaigns' },
    { path: '/admin/partners', icon: Store, label: 'Partners' },
    { path: '/admin/bridge', icon: ArrowRightLeft, label: 'Bridge Manager' },
    { path: '/admin/mod-queue', icon: CheckSquare, label: 'Mod Queue' },
    { path: '/admin/escalation', icon: AlertTriangle, label: 'Escalations' },
  ];

  const businessNav = [
    { path: '/', icon: Home, label: 'Dashboard' },
    { path: '/scan', icon: Store, label: 'Scan QR' },
    { path: '/business/offers', icon: Megaphone, label: 'My Offers' },
    { path: '/business/history', icon: BarChart2, label: 'Redemption History' },
    { path: '/partner-float', icon: ArrowRightLeft, label: 'Float Monitor' },
    { path: '/settings', icon: Settings, label: 'Settings' },
  ];

  const isAdminSection = location.pathname.startsWith('/admin');
  const isBusinessSection = location.pathname.startsWith('/business') || location.pathname === '/scan' || location.pathname === '/partner-float';
  const isBusiness = user?.role === 'business';

  const partnerNav = !['business', 'admin'].includes(user?.role || '') ? [
    { path: '/partner-signup', icon: Store, label: 'Become a Partner' },
  ] : [];

  const navItems = isAdminSection ? adminNav 
    : (isBusiness && isBusinessSection) ? businessNav
    : [...memberNav, ...roleBasedNav, ...modNav, ...onboardingNav, ...volunteerNav, ...partnerNav];

  return (
    <aside className="hidden md:flex flex-col w-64 h-screen bg-white border-r border-gray-200 fixed left-0 top-0 z-50">
      {/* Logo */}
      <div className="p-6 border-b border-gray-100">
        <div className="flex items-center gap-2">
          <div className="bg-enb-green p-2 rounded-xl">
            <ENBLeaf size={28} />
          </div>
          <span className="font-bold text-xl tracking-tight text-enb-text-primary">Eco-Neighbor</span>
        </div>
      </div>

      {/* Admin / Member toggle — only shown for admin users */}
      {user.role === 'admin' && (
        <div className="px-4 pt-4 pb-1 flex gap-2">
          <Link to="/" className={`flex-1 text-center text-xs font-semibold py-2 rounded-lg transition-colors ${!isAdminSection ? 'bg-enb-green text-white' : 'bg-gray-100 text-gray-500 hover:bg-gray-200'}`}>
            Member View
          </Link>
          <Link to="/admin" className={`flex-1 text-center text-xs font-semibold py-2 rounded-lg transition-colors ${isAdminSection ? 'bg-enb-green text-white' : 'bg-gray-100 text-gray-500 hover:bg-gray-200'}`}>
            Admin Panel
          </Link>
        </div>
      )}

      {/* Onboarding tab — only shown for onboarding_team role */}
      {user.role === 'onboarding_team' && (
        <div className="px-4 pt-4 pb-1 flex gap-2">
          <Link to="/" className={`flex-1 text-center text-xs font-semibold py-2 rounded-lg transition-colors ${!location.pathname.startsWith('/onboarding') ? 'bg-enb-green text-white' : 'bg-gray-100 text-gray-500 hover:bg-gray-200'}`}>
            Member View
          </Link>
          <Link to="/onboarding-queue" className={`flex-1 text-center text-xs font-semibold py-2 rounded-lg transition-colors ${location.pathname.startsWith('/onboarding') ? 'bg-blue-600 text-white' : 'bg-gray-100 text-gray-500 hover:bg-gray-200'}`}>
            Onboarding
          </Link>
        </div>
      )}

      {/* Business Member / Business Admin toggle — only shown for business role */}
      {user.role === 'business' && (
        <div className="px-4 pt-4 pb-1 flex gap-2">
          <Link to="/" className={`flex-1 text-center text-xs font-semibold py-2 rounded-lg transition-colors ${!isBusinessSection ? 'bg-enb-green text-white' : 'bg-gray-100 text-gray-500 hover:bg-gray-200'}`}>
            Member View
          </Link>
          <Link to="/business/offers" className={`flex-1 text-center text-xs font-semibold py-2 rounded-lg transition-colors ${isBusinessSection ? 'bg-enb-teal text-white' : 'bg-gray-100 text-gray-500 hover:bg-gray-200'}`}>
            Business Admin
          </Link>
        </div>
      )}

      {/* Nav Items */}
      <nav className="flex-1 p-4 space-y-1 overflow-y-auto">
        {navItems.map((item) => {
          const isActive = item.path === '/admin'
            ? location.pathname === '/admin'
            : location.pathname === item.path || location.pathname.startsWith(item.path + '/');
          return (
            <Link key={item.path} to={item.path}>
              <div className={`flex items-center gap-3 px-4 py-3 rounded-xl transition-all ${isActive ? 'bg-enb-green/10 text-enb-green font-semibold' : 'text-gray-500 hover:bg-gray-50 hover:text-gray-900'}`}>
                <item.icon className={`w-5 h-5 ${isActive ? 'text-enb-green' : 'text-gray-400'}`} />
                <span>{item.label}</span>
                {isActive && (
                  <motion.div
                    layoutId="desktop-nav-indicator"
                    className="ml-auto w-1.5 h-1.5 rounded-full bg-enb-green"
                  />
                )}
              </div>
            </Link>
          );
        })}
      </nav>

      {/* User footer — language toggle + account switcher */}
      <div className="p-2 border-t border-gray-100">
        <div className="px-2 pb-1">
          <LanguageToggle className="w-full justify-center" />
        </div>
        <AccountSwitcher compact={false} />
      </div>
    </aside>
  );
}
