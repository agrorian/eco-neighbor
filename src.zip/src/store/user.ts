import { create } from 'zustand';

export type UserRole = 'member' | 'business' | 'admin' | 'moderator' | 'organiser' | 'founder' | 'super_admin';
export type UserTier = 'Newcomer' | 'Helper' | 'Guardian' | 'Pillar' | 'Founder';

export function getTier(repScore: number): UserTier {
  if (repScore >= 100000) return 'Founder';
  if (repScore >= 50000) return 'Pillar';
  if (repScore >= 20000) return 'Guardian';
  if (repScore >= 5000) return 'Helper';
  return 'Newcomer';
}

interface UserState {
  user: {
    id: string;
    email: string;
    full_name: string;
    neighbourhood: string;
    profession: string;
    enb_local_bal: number;
    enb_global_bal: number;
    rep_score: number;
    tier: UserTier;
    role: UserRole;
    wallet_address?: string;
    whatsapp_number?: string;
    profile_pic_url?: string;
    lifetime_earned?: number;
    referred_by?: string;
    referral_code?: string;
    consecutive_absences?: number;
    cnic_number?: string;
    cnic_photo_url?: string;
    cnic_verified?: boolean;
    cnic_submitted_at?: string;
  } | null;
  setUser: (user: UserState['user']) => void;
  logout: () => void;
}

export const useUserStore = create<UserState>((set) => ({
  user: null,
  setUser: (user) => set({ user }),
  logout: () => set({ user: null }),
}));
