import { useState, useEffect } from 'react';
import { Search, Zap, MoreVertical, User, Shield, AlertTriangle, Loader2, CheckCircle, Clock, XCircle, ExternalLink, Pencil, Save, X, Trash2 } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Dialog, DialogContent } from '@/components/ui/dialog';
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger } from '@/components/ui/dropdown-menu';
import { supabase } from '@/lib/supabase';
import { useUserStore } from '@/store/user';
import LocationPicker, { LocationValue } from '@/components/LocationPicker';
import { PROFESSIONS, USER_TIERS, USER_ROLES } from '@/lib/constants';

interface DBUser {
  id: string; full_name: string; email: string; role: string;
  rep_score: number; enb_local_bal: number; tier: string;
  whatsapp_number?: string; neighbourhood?: string; profession?: string;
  wallet_address?: string; is_active: boolean;
  cnic_number?: string; cnic_photo_url?: string; cnic_verified?: boolean; cnic_submitted_at?: string;
}

export default function UserManagement() {
  const { user: adminUser } = useUserStore();
  const [searchTerm, setSearchTerm] = useState('');
  const [users, setUsers] = useState<DBUser[]>([]);
  const [loading, setLoading] = useState(true);
  const [airdropTarget, setAirdropTarget] = useState<DBUser | null>(null);
  const [airdropAmount, setAirdropAmount] = useState('');
  const [airdropReason, setAirdropReason] = useState('');
  const [airdropping, setAirdropping] = useState(false);
  const [airdropSuccess, setAirdropSuccess] = useState('');
  const [airdropError, setAirdropError] = useState('');
  const [verifyTarget, setVerifyTarget] = useState<DBUser | null>(null);
  const [verifying, setVerifying] = useState(false);
  const [verifySuccess, setVerifySuccess] = useState('');

  // ── Delete Account ───────────────────────────────────────────────────────
  const [deleteTarget, setDeleteTarget] = useState<DBUser | null>(null);
  const [deleteConfirmText, setDeleteConfirmText] = useState('');
  const [deleting, setDeleting] = useState(false);
  const [deleteError, setDeleteError] = useState('');

  // ── Edit Profile ────────────────────────────────────────────────────────
  const [editTarget, setEditTarget] = useState<DBUser | null>(null);
  const [editForm, setEditForm] = useState<Partial<DBUser>>({});
  const [editLocation, setEditLocation] = useState<LocationValue>({
    country: '', countryCode: '', province: '', city: '', neighbourhood: '',
  });
  const [saving, setSaving] = useState(false);
  const [saveError, setSaveError] = useState('');
  const [saveSuccess, setSaveSuccess] = useState('');

  const openEdit = (u: DBUser) => {
    setEditTarget(u);
    setEditForm({
      full_name:       u.full_name || '',
      profession:      u.profession || '',
      whatsapp_number: u.whatsapp_number || '',
      wallet_address:  u.wallet_address || '',
      role:            u.role || 'member',
      tier:            u.tier || 'Newcomer',
      cnic_verified:   u.cnic_verified || false,
      is_active:       u.is_active !== false,
    });
    // Parse neighbourhood back into location — neighbourhood field stores "Neighbourhood, City, Province, Country"
    // For simplicity, pre-fill neighbourhood from existing data
    setEditLocation({
      country:      '',
      countryCode:  '',
      province:     '',
      city:         '',
      neighbourhood: u.neighbourhood || '',
    });
    setSaveError('');
    setSaveSuccess('');
  };

  const handleSaveEdit = async () => {
    if (!editTarget) return;
    setSaving(true);
    setSaveError('');
    // Build neighbourhood string from location picker
    const locationParts = [
      editLocation.neighbourhood,
      editLocation.city,
      editLocation.province,
      editLocation.country,
    ].filter(Boolean);
    const neighbourhoodStr = locationParts.length > 0
      ? locationParts.join(', ')
      : editTarget.neighbourhood || null;

    const { error } = await supabase
      .from('users')
      .update({
        full_name:       editForm.full_name?.trim() || null,
        neighbourhood:   neighbourhoodStr,
        profession:      editForm.profession?.trim() || null,
        whatsapp_number: editForm.whatsapp_number?.trim() || null,
        wallet_address:  editForm.wallet_address?.trim() || null,
        role:            editForm.role,
        tier:            editForm.tier,
        cnic_verified:   editForm.cnic_verified,
        is_active:       editForm.is_active,
      })
      .eq('id', editTarget.id);
    setSaving(false);
    if (error) { setSaveError(error.message); return; }
    setSaveSuccess('✅ Profile updated successfully');
    fetchUsers();
    setTimeout(() => { setEditTarget(null); setSaveSuccess(''); }, 1500);
  };

  useEffect(() => { fetchUsers(); }, []);

  const fetchUsers = async () => {
    setLoading(true);
    const { data, error } = await supabase
      .from('users')
      .select('id, full_name, email, role, rep_score, enb_local_bal, tier, whatsapp_number, neighbourhood, profession, wallet_address, is_active, cnic_number, cnic_photo_url, cnic_verified, cnic_submitted_at')
      .order('rep_score', { ascending: false });
    if (!error && data) setUsers(data);
    setLoading(false);
  };

  const handleAirdrop = async () => {
    if (!adminUser || !airdropTarget || !airdropAmount || !airdropReason) return;
    setAirdropping(true);
    setAirdropError('');
    try {
      const { data, error } = await supabase.rpc('airdrop_enb', {
        p_admin_id: adminUser.id,
        p_target_user_id: airdropTarget.id,
        p_amount: parseFloat(airdropAmount),
        p_reason: airdropReason,
      });
      if (error) throw error;
      if (!data?.success) throw new Error(data?.error || 'Airdrop failed');
      setAirdropSuccess(`✅ ${parseFloat(airdropAmount).toLocaleString()} ENB sent to ${airdropTarget.full_name}`);
      setAirdropAmount(''); setAirdropReason('');
      fetchUsers();
      setTimeout(() => { setAirdropTarget(null); setAirdropSuccess(''); }, 2000);
    } catch (err: any) {
      setAirdropError(err.message || 'Airdrop failed');
    } finally {
      setAirdropping(false);
    }
  };

  const handleToggleActive = async (u: DBUser) => {
    const { error } = await supabase.from('users').update({ is_active: !u.is_active }).eq('id', u.id);
    if (!error) fetchUsers();
  };

  const handleChangeRole = async (u: DBUser, newRole: string) => {
    const { error } = await supabase.from('users').update({ role: newRole }).eq('id', u.id);
    if (!error) fetchUsers();
  };

  const handleVerify = async () => {
    if (!verifyTarget) return;
    setVerifying(true);
    const { error } = await supabase
      .from('users')
      .update({ cnic_verified: true })
      .eq('id', verifyTarget.id);
    setVerifying(false);
    if (!error) {
      setVerifySuccess('✅ Identity verified successfully');
      fetchUsers();
      setTimeout(() => { setVerifyTarget(null); setVerifySuccess(''); }, 2000);
    }
  };

  const handleDelete = async () => {
    if (!deleteTarget) return;
    setDeleting(true);
    setDeleteError('');
    try {
      // Step 1: delete from public.users (cascades to all related rows)
      const { error: dbError } = await supabase
        .from('users')
        .delete()
        .eq('id', deleteTarget.id);
      if (dbError) throw dbError;

      // Step 2: delete from auth.users via SECURITY DEFINER RPC
      const { error: authError } = await supabase.rpc('admin_delete_auth_user', {
        p_user_id: deleteTarget.id,
      });
      if (authError) throw authError;

      setDeleteTarget(null);
      setDeleteConfirmText('');
      fetchUsers();
    } catch (err: any) {
      setDeleteError(err.message || 'Delete failed. Please try again.');
    } finally {
      setDeleting(false);
    }
  };

  const filteredUsers = users.filter(u =>
    (u.full_name || '').toLowerCase().includes(searchTerm.toLowerCase()) ||
    (u.email || '').toLowerCase().includes(searchTerm.toLowerCase())
  );

  const ROLE_COLORS: Record<string, string> = {
    admin: 'bg-purple-100 text-purple-800', founder: 'bg-enb-gold/10 text-amber-700',
    moderator: 'bg-blue-100 text-blue-800', organiser: 'bg-teal-100 text-teal-800',
    business: 'bg-pink-100 text-pink-800', member: 'bg-gray-100 text-gray-700',
  };

  return (
    <div className="space-y-6">
      <header className="flex justify-between items-center flex-wrap gap-3">
        <div>
          <h1 className="text-2xl font-bold text-enb-text-primary">User Management</h1>
          <p className="text-sm text-enb-text-secondary">{users.length} total members</p>
        </div>
        <div className="relative w-64">
          <Search className="absolute left-3 top-3 w-4 h-4 text-gray-400" />
          <Input placeholder="Search users..." className="pl-9" value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)} />
        </div>
      </header>

      {loading ? (
        <div className="flex justify-center py-12">
          <Loader2 className="w-8 h-8 animate-spin text-enb-green" />
        </div>
      ) : (
        <div className="bg-white rounded-xl shadow-sm border border-gray-100 overflow-hidden">
          <table className="w-full text-left text-sm">
            <thead className="bg-gray-50 border-b border-gray-100">
              <tr>
                <th className="px-3 py-4 font-medium text-gray-500 w-[220px]">User</th>
                <th className="px-3 py-4 font-medium text-gray-500 w-[110px]">Role</th>
                <th className="px-3 py-4 font-medium text-gray-500 w-[100px]">Tier</th>
                <th className="px-3 py-4 font-medium text-gray-500 text-right w-[70px]">Rep</th>
                <th className="px-3 py-4 font-medium text-gray-500 text-right w-[100px]">ENB Balance</th>
                <th className="px-3 py-4 font-medium text-gray-500 text-center w-[90px]">Identity</th>
                <th className="px-3 py-4 font-medium text-gray-500 text-right w-[80px]">Status</th>
                <th className="px-3 py-4 font-medium text-gray-500 text-right w-[60px]">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-gray-100">
              {filteredUsers.map((u) => (
                <tr key={u.id} className="hover:bg-gray-50 transition-colors">
                  <td className="px-3 py-3">
                    <div className="flex items-center gap-2">
                      <div className="w-7 h-7 rounded-full bg-gray-100 flex items-center justify-center font-bold text-gray-500 text-xs shrink-0">
                        {(u.full_name || u.email || '?').charAt(0).toUpperCase()}
                      </div>
                      <div className="min-w-0">
                        <div className="font-medium text-enb-text-primary text-sm truncate">{u.full_name || '—'}</div>
                        <div className="text-xs text-gray-400 truncate">{u.email}</div>
                        {u.neighbourhood && <div className="text-xs text-gray-300 truncate">{u.neighbourhood}</div>}
                      </div>
                    </div>
                  </td>
                  <td className="px-3 py-3">
                    <span className={`inline-flex items-center px-2 py-0.5 rounded-full text-xs font-medium ${ROLE_COLORS[u.role] || 'bg-gray-100 text-gray-700'}`}>
                      {u.role}
                    </span>
                  </td>
                  <td className="px-3 py-3">
                    <span className="inline-flex items-center px-2 py-0.5 rounded-full text-xs font-medium bg-green-100 text-green-800">
                      {u.tier}
                    </span>
                  </td>
                  <td className="px-3 py-3 text-right font-mono text-sm">{(u.rep_score || 0).toLocaleString()}</td>
                  <td className="px-3 py-3 text-right font-mono text-sm">{(u.enb_local_bal || 0).toLocaleString()}</td>
                  <td className="px-3 py-3 text-center">
                    {u.cnic_submitted_at ? (
                      u.cnic_verified ? (
                        <span className="inline-flex items-center gap-1 px-2 py-0.5 text-xs font-semibold rounded-full bg-green-100 text-green-700">
                          <CheckCircle className="w-3 h-3" /> Verified
                        </span>
                      ) : (
                        <span className="inline-flex items-center gap-1 px-2 py-0.5 text-xs font-semibold rounded-full bg-amber-50 text-amber-600">
                          <Clock className="w-3 h-3" /> Pending
                        </span>
                      )
                    ) : (
                      <span className="inline-flex items-center gap-1 px-2 py-0.5 text-xs font-semibold rounded-full bg-gray-100 text-gray-400">
                        <XCircle className="w-3 h-3" /> None
                      </span>
                    )}
                  </td>
                  <td className="px-3 py-3 text-right">
                    <span className={`text-xs font-medium px-2 py-0.5 rounded-full ${u.is_active !== false ? 'bg-green-100 text-green-700' : 'bg-red-100 text-red-700'}`}>
                      {u.is_active !== false ? 'Active' : 'Suspended'}
                    </span>
                  </td>
                  <td className="px-3 py-3 text-right">
                    <DropdownMenu>
                      <DropdownMenuTrigger>
                        <div className="h-8 w-8 flex items-center justify-center rounded hover:bg-gray-100 cursor-pointer">
                          <MoreVertical className="w-4 h-4" />
                        </div>
                      </DropdownMenuTrigger>
                      <DropdownMenuContent align="end" className="w-48">
                        <DropdownMenuItem onClick={() => openEdit(u)} className="text-enb-green font-medium">
                          <Pencil className="w-4 h-4 mr-2" /> Edit Profile
                        </DropdownMenuItem>
                        {u.cnic_submitted_at && !u.cnic_verified && (
                          <DropdownMenuItem onClick={() => setVerifyTarget(u)} className="text-enb-green">
                            <CheckCircle className="w-4 h-4 mr-2" /> Verify Identity
                          </DropdownMenuItem>
                        )}
                        <DropdownMenuItem onClick={() => setAirdropTarget(u)}>
                          <Zap className="w-4 h-4 mr-2 text-enb-gold" /> Airdrop ENB
                        </DropdownMenuItem>
                        <DropdownMenuItem onClick={() => handleChangeRole(u, u.role === 'moderator' ? 'member' : 'moderator')}>
                          <Shield className="w-4 h-4 mr-2" />
                          {u.role === 'moderator' ? 'Remove Moderator' : 'Make Moderator'}
                        </DropdownMenuItem>
                        <DropdownMenuItem onClick={() => handleChangeRole(u, u.role === 'admin' ? 'member' : 'admin')}>
                          <User className="w-4 h-4 mr-2" />
                          {u.role === 'admin' ? 'Remove Admin' : 'Make Admin'}
                        </DropdownMenuItem>
                        <DropdownMenuItem onClick={() => handleToggleActive(u)} className={u.is_active !== false ? 'text-red-600' : 'text-green-600'}>
                          <AlertTriangle className="w-4 h-4 mr-2" />
                          {u.is_active !== false ? 'Suspend Account' : 'Reactivate Account'}
                        </DropdownMenuItem>
                        {adminUser?.role === 'super_admin' && (
                          <DropdownMenuItem
                            onClick={() => { setDeleteTarget(u); setDeleteConfirmText(''); setDeleteError(''); }}
                            className="text-red-600 font-medium focus:text-red-700 focus:bg-red-50"
                          >
                            <Trash2 className="w-4 h-4 mr-2" /> Delete Account
                          </DropdownMenuItem>
                        )}
                      </DropdownMenuContent>
                    </DropdownMenu>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
          {filteredUsers.length === 0 && (
            <div className="text-center py-12 text-enb-text-secondary">No users found.</div>
          )}
        </div>
      )}

      {/* Airdrop Modal */}
      <Dialog open={!!airdropTarget} onOpenChange={(open) => !open && setAirdropTarget(null)}>
        <DialogContent className="max-w-sm">
          <div className="space-y-4 p-2">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 bg-enb-gold/10 rounded-full flex items-center justify-center">
                <Zap className="w-5 h-5 text-enb-gold" />
              </div>
              <div>
                <h3 className="font-bold text-enb-text-primary">Airdrop ENB</h3>
                <p className="text-xs text-gray-500">To: {airdropTarget?.full_name || airdropTarget?.email}</p>
              </div>
            </div>

            {airdropSuccess ? (
              <div className="bg-green-50 border border-green-200 rounded-xl p-4 text-sm text-green-700 text-center font-medium">
                {airdropSuccess}
              </div>
            ) : (
              <>
                <div className="space-y-3">
                  <div>
                    <label className="text-xs font-medium text-gray-500 uppercase tracking-wider">ENB Amount</label>
                    <Input type="number" value={airdropAmount} onChange={(e) => setAirdropAmount(e.target.value)}
                      placeholder="e.g. 1000" className="mt-1 font-mono" />
                  </div>
                  <div>
                    <label className="text-xs font-medium text-gray-500 uppercase tracking-wider">Reason</label>
                    <Input value={airdropReason} onChange={(e) => setAirdropReason(e.target.value)}
                      placeholder="e.g. Community event bonus" className="mt-1" />
                  </div>
                </div>
                {airdropError && <p className="text-sm text-red-500">{airdropError}</p>}
                <div className="flex gap-2">
                  <Button variant="outline" onClick={() => setAirdropTarget(null)} className="flex-1">Cancel</Button>
                  <Button onClick={handleAirdrop} disabled={!airdropAmount || !airdropReason || airdropping}
                    className="flex-1 bg-enb-gold hover:bg-enb-gold/90 text-white">
                    {airdropping ? <Loader2 className="w-4 h-4 animate-spin" /> : `Send ${parseFloat(airdropAmount || '0').toLocaleString()} ENB`}
                  </Button>
                </div>
              </>
            )}
          </div>
        </DialogContent>
      </Dialog>

      {/* Identity Verification Modal */}
      <Dialog open={!!verifyTarget} onOpenChange={(open) => !open && setVerifyTarget(null)}>
        <DialogContent className="max-w-sm">
          <div className="space-y-4 p-2">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 bg-enb-green/10 rounded-full flex items-center justify-center">
                <Shield className="w-5 h-5 text-enb-green" />
              </div>
              <div>
                <h3 className="font-bold text-enb-text-primary">Verify Identity</h3>
                <p className="text-xs text-gray-500">{verifyTarget?.full_name}</p>
              </div>
            </div>

            {verifySuccess ? (
              <div className="bg-green-50 border border-green-200 rounded-xl p-4 text-sm text-green-700 text-center font-medium">
                {verifySuccess}
              </div>
            ) : (
              <div className="space-y-3">
                <div className="bg-gray-50 rounded-xl p-3 space-y-1 text-sm">
                  <div><span className="font-medium text-gray-500">ID Number:</span> <span className="font-mono text-enb-text-primary">{verifyTarget?.cnic_number || '—'}</span></div>
                  <div><span className="font-medium text-gray-500">Submitted:</span> <span>{verifyTarget?.cnic_submitted_at ? new Date(verifyTarget.cnic_submitted_at).toLocaleDateString('en-PK') : '—'}</span></div>
                  <div><span className="font-medium text-gray-500">Neighbourhood:</span> <span>{verifyTarget?.neighbourhood}</span></div>
                </div>
                {verifyTarget?.cnic_photo_url && (
                  <div className="space-y-1">
                    <p className="text-xs font-medium text-gray-500">ID Photo</p>
                    <a href={verifyTarget.cnic_photo_url} target="_blank" rel="noopener noreferrer">
                      <img src={verifyTarget.cnic_photo_url} alt="CNIC" className="w-full h-36 object-cover rounded-xl border border-gray-200 hover:opacity-90 transition-opacity" />
                      <p className="text-xs text-center text-enb-green mt-1 flex items-center justify-center gap-1">
                        <ExternalLink className="w-3 h-3" /> Open full size
                      </p>
                    </a>
                  </div>
                )}
                {!verifyTarget?.cnic_photo_url && (
                  <div className="bg-amber-50 border border-amber-200 rounded-xl p-3 text-xs text-amber-700">
                    ⚠️ No ID photo submitted. International member or photo upload failed.
                  </div>
                )}
                <p className="text-xs text-gray-400">
                  By clicking Verify, you confirm you have reviewed the ID and it matches the user's profile.
                </p>
                <div className="flex gap-2">
                  <Button variant="outline" onClick={() => setVerifyTarget(null)} className="flex-1">Cancel</Button>
                  <Button onClick={handleVerify} disabled={verifying}
                    className="flex-1 bg-enb-green hover:bg-enb-green/90 text-white">
                    {verifying ? <Loader2 className="w-4 h-4 animate-spin" /> : '✓ Mark as Verified'}
                  </Button>
                </div>
              </div>
            )}
          </div>
        </DialogContent>
      </Dialog>
      {/* Edit Profile Modal */}
      <Dialog open={!!editTarget} onOpenChange={(open) => !open && setEditTarget(null)}>
        <DialogContent className="max-w-md">
          <div className="space-y-4 p-2">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 bg-enb-green/10 rounded-full flex items-center justify-center">
                <Pencil className="w-5 h-5 text-enb-green" />
              </div>
              <div>
                <h3 className="font-bold text-enb-text-primary">Edit Profile</h3>
                <p className="text-xs text-gray-500">{editTarget?.email}</p>
              </div>
            </div>

            {saveSuccess ? (
              <div className="bg-green-50 border border-green-200 rounded-xl p-4 text-sm text-green-700 text-center font-medium">
                {saveSuccess}
              </div>
            ) : (
              <div className="space-y-3 max-h-[60vh] overflow-y-auto pr-1">

                {/* Personal Info */}
                <p className="text-[10px] font-bold text-enb-text-secondary uppercase tracking-wider pt-1">Personal Info</p>

                <div>
                  <label className="text-xs font-medium text-gray-500">Full Name</label>
                  <Input value={editForm.full_name || ''} onChange={e => setEditForm(f => ({ ...f, full_name: e.target.value }))}
                    placeholder="Full name" className="mt-1" />
                </div>

                {/* Location Picker */}
                <LocationPicker
                  value={editLocation}
                  onChange={setEditLocation}
                />

                <div>
                  <label className="text-xs font-medium text-gray-500">Profession</label>
                  <select value={editForm.profession || ''}
                    onChange={e => setEditForm(f => ({ ...f, profession: e.target.value }))}
                    className="mt-1 w-full text-sm px-3 py-2 rounded-lg border border-gray-200 bg-white outline-none focus:border-enb-green text-enb-text-primary">
                    <option value="">Select profession</option>
                    {PROFESSIONS.map(p => <option key={p} value={p}>{p}</option>)}
                  </select>
                </div>
                <div>
                  <label className="text-xs font-medium text-gray-500">WhatsApp Number</label>
                  <Input value={editForm.whatsapp_number || ''} onChange={e => setEditForm(f => ({ ...f, whatsapp_number: e.target.value }))}
                    placeholder="e.g. 03001234567" className="mt-1" />
                </div>
                <div>
                  <label className="text-xs font-medium text-gray-500">Solana Wallet Address</label>
                  <Input value={editForm.wallet_address || ''} onChange={e => setEditForm(f => ({ ...f, wallet_address: e.target.value }))}
                    placeholder="Solana public key" className="mt-1 font-mono text-xs" />
                </div>

                {/* Role & Tier */}
                <p className="text-[10px] font-bold text-enb-text-secondary uppercase tracking-wider pt-1">Role & Tier</p>

                <div className="grid grid-cols-2 gap-3">
                  <div>
                    <label className="text-xs font-medium text-gray-500">Role</label>
                    <select value={editForm.role || 'member'}
                      onChange={e => setEditForm(f => ({ ...f, role: e.target.value }))}
                      className="mt-1 w-full text-sm px-3 py-2 rounded-lg border border-gray-200 bg-white outline-none focus:border-enb-green text-enb-text-primary">
                      {USER_ROLES.map(r => <option key={r} value={r}>{r}</option>)}
                    </select>
                  </div>
                  <div>
                    <label className="text-xs font-medium text-gray-500">Tier</label>
                    <select value={editForm.tier || 'Newcomer'}
                      onChange={e => setEditForm(f => ({ ...f, tier: e.target.value }))}
                      className="mt-1 w-full text-sm px-3 py-2 rounded-lg border border-gray-200 bg-white outline-none focus:border-enb-green text-enb-text-primary">
                      {USER_TIERS.map(t => <option key={t} value={t}>{t}</option>)}
                    </select>
                  </div>
                </div>

                {/* Status & Verification */}
                <p className="text-[10px] font-bold text-enb-text-secondary uppercase tracking-wider pt-1">Status</p>

                <div className="flex gap-4">
                  <label className="flex items-center gap-2 cursor-pointer">
                    <input type="checkbox" checked={editForm.is_active !== false}
                      onChange={e => setEditForm(f => ({ ...f, is_active: e.target.checked }))}
                      className="w-4 h-4 accent-enb-green rounded" />
                    <span className="text-sm text-enb-text-primary">Account Active</span>
                  </label>
                  <label className="flex items-center gap-2 cursor-pointer">
                    <input type="checkbox" checked={!!editForm.cnic_verified}
                      onChange={e => setEditForm(f => ({ ...f, cnic_verified: e.target.checked }))}
                      className="w-4 h-4 accent-enb-green rounded" />
                    <span className="text-sm text-enb-text-primary">Identity Verified</span>
                  </label>
                </div>

                {saveError && (
                  <p className="text-sm text-red-500 bg-red-50 border border-red-200 rounded-lg p-2">{saveError}</p>
                )}

                <div className="flex gap-2 pt-1">
                  <Button variant="outline" onClick={() => setEditTarget(null)} className="flex-1">
                    <X className="w-4 h-4 mr-1" /> Cancel
                  </Button>
                  <Button onClick={handleSaveEdit} disabled={saving}
                    className="flex-1 bg-enb-green hover:bg-enb-green/90 text-white">
                    {saving
                      ? <Loader2 className="w-4 h-4 animate-spin" />
                      : <><Save className="w-4 h-4 mr-1" /> Save Changes</>
                    }
                  </Button>
                </div>
              </div>
            )}
          </div>
        </DialogContent>
      </Dialog>

      {/* Delete Account Modal */}
      <Dialog open={!!deleteTarget} onOpenChange={(open) => { if (!open) { setDeleteTarget(null); setDeleteConfirmText(''); setDeleteError(''); } }}>
        <DialogContent className="max-w-sm">
          <div className="space-y-4 p-2">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 bg-red-100 rounded-full flex items-center justify-center">
                <Trash2 className="w-5 h-5 text-red-600" />
              </div>
              <div>
                <h3 className="font-bold text-enb-text-primary">Delete Account</h3>
                <p className="text-xs text-gray-500">This action cannot be undone</p>
              </div>
            </div>

            <div className="bg-red-50 border border-red-200 rounded-xl p-3 space-y-1 text-sm">
              <div><span className="font-medium text-gray-500">Name:</span> <span className="font-semibold text-enb-text-primary">{deleteTarget?.full_name || '—'}</span></div>
              <div><span className="font-medium text-gray-500">Email:</span> <span className="font-mono text-red-700">{deleteTarget?.email}</span></div>
              <div><span className="font-medium text-gray-500">ENB Balance:</span> <span>{(deleteTarget?.enb_local_bal || 0).toLocaleString()} ENB</span></div>
            </div>

            <p className="text-sm text-gray-600 leading-relaxed">
              This will permanently delete the user's account, profile, submissions, and all associated data from the database. Their auth login will also be removed.
            </p>

            <div>
              <label className="text-xs font-medium text-gray-500 uppercase tracking-wider">
                Type <span className="font-mono text-red-600">DELETE</span> to confirm
              </label>
              <Input
                value={deleteConfirmText}
                onChange={e => { setDeleteConfirmText(e.target.value); setDeleteError(''); }}
                placeholder="Type DELETE"
                className="mt-1 font-mono border-red-200 focus:border-red-400"
              />
            </div>

            {deleteError && (
              <p className="text-sm text-red-500 bg-red-50 border border-red-200 rounded-lg p-2">{deleteError}</p>
            )}

            <div className="flex gap-2">
              <Button variant="outline" onClick={() => { setDeleteTarget(null); setDeleteConfirmText(''); setDeleteError(''); }} className="flex-1">
                Cancel
              </Button>
              <Button
                onClick={handleDelete}
                disabled={deleteConfirmText !== 'DELETE' || deleting}
                className="flex-1 bg-red-600 hover:bg-red-700 text-white disabled:opacity-40"
              >
                {deleting ? <Loader2 className="w-4 h-4 animate-spin" /> : <><Trash2 className="w-4 h-4 mr-1" /> Delete Permanently</>}
              </Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>

    </div>
  );
}
